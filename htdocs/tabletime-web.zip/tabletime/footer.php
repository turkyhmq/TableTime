<footer>
<div align="center" style="color: #FFF">&copy All rights reserved</div>
</footer>